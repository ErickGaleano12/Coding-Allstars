document.addEventListener("DOMContentLoaded", function() {
    const firstImage = document.getElementById("first-image");
    const secondImage = document.getElementById("second-image");
    const ThirdImage = document.getElementById("Third-image");
    const FourthImage = document.getElementById("Fourth-image");
    const FifthImage = document.getElementById("Fifth-image");
    const tooltip = document.createElement("div");
    tooltip.className = "tooltip";
    
    
    firstImage.parentNode.insertBefore(tooltip, firstImage.nextSibling);
    
    firstImage.addEventListener("mouseover", function() {
        tooltip.textContent = "With great power comes great responsibility";
        tooltip.style.opacity = "1";
    });

    secondImage.addEventListener("mouseover", function() {
        tooltip.textContent = "The king of Wakanda";
        tooltip.style.opacity = "1";
    });

    ThirdImage.addEventListener("mouseover", function() {
        tooltip.textContent = "The Dark knight";
        tooltip.style.opacity = "1";
    });

    FourthImage.addEventListener("mouseover", function() {
        tooltip.textContent = "The first Avenger";
        tooltip.style.opacity = "1";
    });

    FifthImage.addEventListener("mouseover", function() {
        tooltip.textContent = "Hulk Smash";
        tooltip.style.opacity = "1";
    });
    
    firstImage.addEventListener("mouseout", function() {
        tooltip.style.opacity = "0";
    });

    secondImage.addEventListener("mouseout", function() {
        tooltip.style.opacity = "0";
    });

    ThirdImage.addEventListener("mouseout", function() {
        tooltip.style.opacity = "0";
    });

    FourthImage.addEventListener("mouseout", function() {
        tooltip.style.opacity = "0";
    });

    FifthImage.addEventListener("mouseout", function() {
        tooltip.style.opacity = "0";
    });
});

const toggleButton = document.getElementById("toggleButton");
const ButtonPanther = document.getElementById("ButtonPanther");
const ButtonSpider = document.getElementById("ButtonSpider");
const ButtonCaptain = document.getElementById("ButtonCaptain");
const ButtonHulk = document.getElementById("ButtonHulk");
const contentDiv = document.getElementById("batman");
const contentDiv2 = document.getElementById("black-panther");
const contentDiv3 = document.getElementById("spiderman");
const contentDiv4 = document.getElementById("captain");
const contentDiv5 = document.getElementById("hulk");

let openContent = null;

toggleButton.addEventListener("click", function() {
    toggleContent(contentDiv);
});

ButtonPanther.addEventListener("click", function() {
    toggleContent(contentDiv2);
});

ButtonSpider.addEventListener("click", function() {
    toggleContent(contentDiv3);
});

ButtonCaptain.addEventListener("click", function() {
    toggleContent(contentDiv4);
});

ButtonHulk.addEventListener("click", function() {
    toggleContent(contentDiv5);
});

function toggleContent(content) {
    if (openContent) {
        openContent.classList.add("hidden");
    }
    if (openContent !== content) {
        content.classList.remove("hidden");
        openContent = content;
    } else {
        openContent = null;
    }
}
